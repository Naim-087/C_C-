// DSP: "Hotel management system"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <windows.h>
#include "design.h"

#define MAX_NAME_LENGTH 50
#define MAX_DATE_LENGTH 11
#define MAX_TYPE_LENGTH 10
#define MAX_MAIL_LENGTH 50
#define MAX_PHONE_LENGTH 12
#define MAX_NID_LENGTH 15

struct Room
{
    int roomNumber;
    bool isOccupied;
    bool req;
    int cost;
    int pay;
    char guestName[MAX_NAME_LENGTH];
    char room_type[MAX_TYPE_LENGTH];
    char mail[MAX_MAIL_LENGTH];
    char phone[MAX_PHONE_LENGTH];
    char nid[MAX_NID_LENGTH];
    char checkInDate[MAX_DATE_LENGTH];
    char checkOutDate[MAX_DATE_LENGTH];
    struct Room *next;
};

struct Room *head = NULL;
struct Room *tail = NULL;

void insertRoom(int roomNumber, bool isOccupied, bool req, int cost, int pay, const char *room_type, const char *guestName, const char *mail, const char *phone, const char *nid, const char *checkInDate, const char *checkOutDate)
{
    struct Room *newRoom = (struct Room *)malloc(sizeof(struct Room));
    newRoom->roomNumber = roomNumber;
    newRoom->isOccupied = isOccupied;
    newRoom->req = req;
    newRoom->cost = cost;
    newRoom->pay = pay;
    strcpy(newRoom->room_type, room_type);
    strcpy(newRoom->guestName, guestName);
    strcpy(newRoom->mail, mail);
    strcpy(newRoom->phone, phone);
    strcpy(newRoom->nid, nid);
    strcpy(newRoom->checkInDate, checkInDate);
    strcpy(newRoom->checkOutDate, checkOutDate);
    if (head == NULL)
    {
        head = newRoom;
        tail = newRoom;
    }
    else
    {
        tail->next = newRoom;
        tail = newRoom;
    }
}

void loadRoomDataFromFile()
{
    FILE *file = fopen("room_data.txt", "r");
    if (file)
    {
        while (!feof(file))
        {
            int roomNumber, isOccupied, req, cost, pay;
            char guestName[MAX_NAME_LENGTH];
            char room_type[MAX_TYPE_LENGTH];
            char mail[MAX_MAIL_LENGTH];
            char phone[MAX_PHONE_LENGTH];
            char nid[MAX_NID_LENGTH];
            char checkInDate[MAX_DATE_LENGTH];
            char checkOutDate[MAX_DATE_LENGTH];

            if (fscanf(file, "%d %d %d %d %d %s %[^,],%s %s %s %s %s\n", &roomNumber, &isOccupied, &req, &cost, &pay, room_type, guestName, mail, phone, nid, checkInDate, checkOutDate) < 9)
            {
                break;
            }

            insertRoom(roomNumber, isOccupied, req, cost, pay, room_type, guestName, mail, phone, nid, checkInDate, checkOutDate);
        }
        fclose(file);
    }
}

void saveRoomDataToFile()
{
    FILE *file = fopen("room_data.txt", "w");
    if (file)
    {
        struct Room *current = head;
        while (current != NULL)
        {
            fprintf(file, "%d %d %d %d %d %s %s, %s %s %s %s %s\n", current->roomNumber, current->isOccupied, current->req, current->cost, current->pay, current->room_type, current->guestName, current->mail, current->phone, current->nid, current->checkInDate, current->checkOutDate);
            current = current->next;
        }
        fclose(file);
    }
}

int daysInMonth(int month, int year)
{
    int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    // For February in a leap year, adjust the number of days
    if (month == 2 && (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)))
        return 29;

    return days[month];
}

bool isDateValid(const char *date)
{
    if (strlen(date) != MAX_DATE_LENGTH - 1)
    {
        return false;
    }
    int day, month, year;
    if (sscanf(date, "%d-%d-%d", &day, &month, &year) != 3)
        return false;

    if (day < 1 || month < 1 || month > 12 || year < 1)
        return false;

    int maxDays = daysInMonth(month, year);
    return day <= maxDays;
}

int calculateDays(const char *checkInDate, const char *checkOutDate)
{
    int dayIn, monthIn, yearIn;
    int dayOut, monthOut, yearOut;

    sscanf(checkInDate, "%d-%d-%d", &dayIn, &monthIn, &yearIn);
    sscanf(checkOutDate, "%d-%d-%d", &dayOut, &monthOut, &yearOut);

    if (!isDateValid(checkInDate) || !isDateValid(checkOutDate))
    {
        printf("Invalid date format.\n");
        return -1; // Return a negative value to indicate an error
    }

    if (yearOut < yearIn || (yearOut == yearIn && monthOut < monthIn) || (yearOut == yearIn && monthOut == monthIn && dayOut < dayIn))
    {
        return -1; // Return a negative value to indicate an error
    }

    int totalDays = 0;

    while (!(dayIn == dayOut && monthIn == monthOut && yearIn == yearOut))
    {
        totalDays++;
        dayIn++;
        if (dayIn > daysInMonth(monthIn, yearIn))
        {
            dayIn = 1;
            monthIn++;
            if (monthIn > 12)
            {
                monthIn = 1;
                yearIn++;
            }
        }
    }

    return totalDays;
}

int opt, opt1, opt2;

void book_a_room()
{
    booking_head("Request");
    printf("\033[1;33m\t\t\t\t    Please use (DD-MM-YYYY) format for dates\033[1;37m\n");
    char checkInDate[MAX_DATE_LENGTH];
    char checkOutDate[MAX_DATE_LENGTH];

back:
    printf("\033[1;36m\n\t\t\t\t\tCheck-in date    : \033[1;37m");
    scanf(" %s", checkInDate);

    if (strcmp(checkInDate, "0") == 0)
    {
        return;
    }

    if (!isDateValid(checkInDate))
    {
        printf("\033[1;36m\n\t\tInvalid check-in date format. Please use DD-MM-YYYY format.\033[1;37m\n");
        Sleep(2000);
        booking_head("Request");
        printf("\033[1;33m\t\t\t\t    Please use (DD-MM-YYYY) format for dates\033[1;37m\n");
        goto back;
    }

back1:
    printf("\033[1;36m\n\t\t\t\t\tCheck-out date   : \033[1;37m");
    scanf(" %s", checkOutDate);

    if (strcmp(checkOutDate, "0") == 0)
    {
        return;
    }

    if (!isDateValid(checkOutDate))
    {
        printf("\033[1;36m\n\t\tInvalid check-out date format. Please use DD-MM-YYYY format.\033[1;37m\n");
        Sleep(2000);
        booking_head("Request");
        printf("\033[1;33m\t\t\t\t    Please use (DD-MM-YYYY) format for dates\033[1;37m\n");
        printf("\033[1;36m\n\t\t\t\t\tCheck-in date    : %s\033[1;37m\n", checkInDate);
        goto back1;
    }
    int d = calculateDays(checkInDate, checkOutDate);
    if (d < 1)
    {
        printf("\033[1;36m\n\t\tInvalid date range! Check-out date is earlier than Check-in date.\033[1;37m\n");
        Sleep(2000);
        goto back1;
    }
back2:
    system("cls");
    branding();
    displayAvailableRooms(checkInDate, checkOutDate);

    int roomNum;
    printf("\033[1;36m\n\t\t\t\t\tEnter room number: \033[1;37m");
    scanf("%d", &roomNum);

    if (roomNum == 0)
    {
        return;
    }

    if (roomNum < 1)
    {
        printf("\n\t\t\t\t\tInvalid room number!\n");
        Sleep(2000);
        goto back2;
    }

    struct Room *current = head;
    while (current != NULL)
    {
        if (current->roomNumber == roomNum)
        {
            // Room is available for the specified dates, so book it
            int currentCheckOutYear, currentCheckOutMonth, currentCheckInYear, currentCheckInMonth;
            sscanf(current->checkOutDate, "%*d-%d-%d", &currentCheckOutMonth, &currentCheckOutYear);
            sscanf(current->checkInDate, "%*d-%d-%d", &currentCheckInMonth, &currentCheckInYear);

            int inputCheckInYear, inputCheckInMonth;
            sscanf(checkInDate, "%*d-%d-%d", &inputCheckInMonth, &inputCheckInYear);

            if ((!current->isOccupied && !current->req) ||
                (strcmp(current->checkOutDate, checkInDate) < 0 || strcmp(current->checkInDate, checkOutDate) > 0) ||
                (currentCheckOutYear != inputCheckInYear || currentCheckOutMonth != inputCheckInMonth))
            {
                current->req = true;
                current->isOccupied = false;
                strcpy(current->checkInDate, checkInDate);
                strcpy(current->checkOutDate, checkOutDate);

                current->pay = current->cost * d;
                system("cls");
                branding();
                printf("\t\t\t\t  --------------------------------------------\n");
                printf("\t\t\t\t  |\033[1;34m              Your Information            \033[1;37m|\n");
                printf("\t\t\t\t  --------------------------------------------\n");
                printf("\033[1;36m\n\t\t\t\t\t Enter Your Name: \033[1;37m");
                scanf(" %[^\n]s", current->guestName);
                printf("\033[1;36m\n\t\t\t\t\t Enter Email    : \033[1;37m");
                scanf(" %s", current->mail);
                printf("\033[1;36m\n\t\t\t\t\t Enter Phone No : \033[1;37m");
                scanf(" %s", current->phone);
                printf("\033[1;36m\n\t\t\t\t\t Enter NID      : \033[1;37m");
                scanf(" %s", current->nid);
                system("cls");
                branding();
                printf("\033[1;33m\t\t\t                 Enter N/n to cancel the booking\033[1;37m\n");
                printf("\033[1;33m\t\t\t            Press Y/y to proceed to complete booking\n\033[1;37m\n");
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                      Name     \033[1;37m|  %s\n", current->guestName);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                      NID      \033[1;37m|  %s\n", current->nid);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                     E-mail    \033[1;37m|  %s\n", current->mail);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                     Phone     \033[1;37m|  +88 %s\n", current->phone);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                    Room No.   \033[1;37m|  %d \n", roomNum);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                    Check In   \033[1;37m|  %s \n", checkInDate);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                    Check Out  \033[1;37m|  %s \n", checkOutDate);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                   Est. Bill   \033[1;37m|  %d \n", current->pay);
                printf("\t\t\t   ---------------------------------------------------------\n");
                char p;
                printf("\n\033[1;36m\t\t\t                      Confirm : \033[1;37m");
                scanf(" %c", &p);
                if (p == 'N' || p == 'n')
                    return;
                else if (p == 'Y' || p == 'y')
                {
                    saveRoomDataToFile();
                    system("cls");
                    branding();
                    printf("\t\t\t   ---------------------------------------------------------\n");
                    printf("\t\t\t\033[1;33m            A request for room No. %d has been booked!\033[1;37m\n", roomNum);
                    printf("\t\t\t\033[1;34m                      Returning to homepage...\033[1;37m\n");
                    printf("\t\t\t   ---------------------------------------------------------\n");
                    Sleep(3000);
                    return;
                }
                // Save updated room data to the file
            }
            else
            {
                printf("\n\033[1;36m\t\t\t                   Room %d is occupied!\033[1;37m\n", roomNum);
                Sleep(2000);
                goto back2;
            }
        }
        current = current->next;
    }
    printf("\n\033[1;36m\t\t\t                   Room %d not found!\033[1;37m\n", roomNum);
    Sleep(2000);
    goto back2;
}

void checkIn()
{
    booking_head("Book");
    printf("\033[1;33m\t\t\t\t    Please use (DD-MM-YYYY) format for dates\033[1;37m\n");
    char checkInDate[MAX_DATE_LENGTH];
    char checkOutDate[MAX_DATE_LENGTH];

back:
    printf("\033[1;36m\n\t\t\t\t\tCheck-in date    : \033[1;37m");
    scanf(" %s", checkInDate);

    if (strcmp(checkInDate, "0") == 0)
    {
        return;
    }

    if (!isDateValid(checkInDate))
    {
        printf("\033[1;36m\n\t\tInvalid check-in date format. Please use DD-MM-YYYY format.\033[1;37m\n");
        Sleep(2000);
        booking_head("Book");
        printf("\033[1;33m\t\t\t\t    Please use (DD-MM-YYYY) format for dates\033[1;37m\n");
        goto back;
    }

back1:
    printf("\033[1;36m\n\t\t\t\t\tCheck-out date   : \033[1;37m");
    scanf(" %s", checkOutDate);

    if (strcmp(checkOutDate, "0") == 0)
    {
        return;
    }

    if (!isDateValid(checkOutDate))
    {
        printf("\033[1;36m\n\t\tInvalid check-out date format. Please use DD-MM-YYYY format.\033[1;37m\n");
        Sleep(2000);
        booking_head("Book");
        printf("\033[1;33m\t\t\t\t    Please use (DD-MM-YYYY) format for dates\033[1;37m\n");
        printf("\033[1;36m\n\t\t\t\t\tCheck-in date    : %s\033[1;37m\n", checkInDate);
        goto back1;
    }
    int d = calculateDays(checkInDate, checkOutDate);
    if (d < 1)
    {
        printf("\033[1;36m\n\t\tInvalid date range! Check-out date is earlier than Check-in date.\033[1;37m\n");
        Sleep(2000);
        goto back1;
    }
back2:
    system("cls");
    branding();
    displayAvailableRooms(checkInDate, checkOutDate);

    int roomNum;
    printf("\033[1;36m\n\t\t\t\t\tEnter room number: \033[1;37m");
    scanf("%d", &roomNum);

    if (roomNum == 0)
    {
        return;
    }

    if (roomNum < 1)
    {
        printf("\n\t\t\t\t\tInvalid room number!\n");
        Sleep(2000);
        goto back2;
    }

    struct Room *current = head;
    while (current != NULL)
    {
        if (current->roomNumber == roomNum)
        {
            // Room is available for the specified dates, so book it
            int currentCheckOutYear, currentCheckOutMonth, currentCheckInYear, currentCheckInMonth;
            sscanf(current->checkOutDate, "%*d-%d-%d", &currentCheckOutMonth, &currentCheckOutYear);
            sscanf(current->checkInDate, "%*d-%d-%d", &currentCheckInMonth, &currentCheckInYear);

            int inputCheckInYear, inputCheckInMonth;
            sscanf(checkInDate, "%*d-%d-%d", &inputCheckInMonth, &inputCheckInYear);

            if ((!current->isOccupied && !current->req) ||
                (strcmp(current->checkOutDate, checkInDate) < 0 || strcmp(current->checkInDate, checkOutDate) > 0) ||
                (currentCheckOutYear != inputCheckInYear || currentCheckOutMonth != inputCheckInMonth))
            {
                current->isOccupied = true;
                current->req = false;
                strcpy(current->checkInDate, checkInDate);
                strcpy(current->checkOutDate, checkOutDate);

                int d = calculateDays(checkInDate, checkOutDate);
                current->pay = current->cost * d;
                system("cls");
                branding();
                printf("\t\t\t\t  --------------------------------------------\n");
                printf("\t\t\t\t  |\033[1;34m             Guest Information            \033[1;37m|\n");
                printf("\t\t\t\t  --------------------------------------------\n");
                printf("\033[1;36m\n\t\t\t\t\tEnter Guest Name: \033[1;37m");
                scanf(" %[^\n]s", current->guestName);
                printf("\033[1;36m\n\t\t\t\t\tEnter Email     : \033[1;37m");
                scanf(" %s", current->mail);
                printf("\033[1;36m\n\t\t\t\t\tEnter Phone No  : \033[1;37m");
                scanf(" %s", current->phone);
                printf("\033[1;36m\n\t\t\t\t\tEnter NID       : \033[1;37m");
                scanf(" %s", current->nid);
                system("cls");
                branding();
                printf("\033[1;33m\t\t\t                 Enter N/n to cancel the booking\033[1;37m\n");
                printf("\033[1;33m\t\t\t            Press Y/y to proceed to complete booking\n\033[1;37m\n");
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                      Name     \033[1;37m|  %s\n", current->guestName);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                      NID      \033[1;37m|  %s\n", current->nid);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                     E-mail    \033[1;37m|  %s\n", current->mail);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                     Phone     \033[1;37m|  +88 %s\n", current->phone);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                    Room No.   \033[1;37m|  %d \n", roomNum);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                    Check In   \033[1;37m|  %s \n", checkInDate);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                    Check Out  \033[1;37m|  %s \n", checkOutDate);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                   Est. Bill   \033[1;37m|  %d \n", current->pay);
                printf("\t\t\t   ---------------------------------------------------------\n");
                char p;
                printf("\n\033[1;36m\t\t\t                      Confirm : \033[1;37m");
                scanf(" %c", &p);
                if (p == 'N' || p == 'n')
                    return;
                else if (p == 'Y' || p == 'y')
                {
                    saveRoomDataToFile();
                    system("cls");
                    branding();
                    printf("\t\t\t   ---------------------------------------------------------\n");
                    printf("\t\t\t\033[1;33m                   Room No. %d has been booked!\033[1;37m\n", roomNum);
                    printf("\t\t\t\033[1;34m                       Returning to admin...\033[1;37m\n");
                    printf("\t\t\t   ---------------------------------------------------------\n");
                    Sleep(3000);
                    return;
                }
                // Save updated room data to the file
            }
            else
            {
                printf("\n\033[1;36m\t\t\t                   Room %d is occupied!\033[1;37m\n", roomNum);
                Sleep(2000);
                goto back2;
            }
        }
        current = current->next;
    }
    printf("\n\033[1;36m\t\t\t                   Room %d not found!\033[1;37m\n", roomNum);
    Sleep(2000);
}

void confirm()
{
    int roomNum;
    printf("\033[1;36m\n\t\t\t\t  Confirm booking number: \033[1;37m");
    scanf("%d", &roomNum);

    if (roomNum < 1)
    {
        printf("Invalid booking number\n");
        Sleep(2000);
        // Need_while_loop_here
        return;
    }

    struct Room *current = head;
    while (current != NULL)
    {
        if (current->roomNumber == roomNum)
        {
            if (current->req)
            {
                current->req = false;
                current->isOccupied = true;
                system("cls");
                branding();
                printf("\033[1;33m\t\t\t                 Enter N/n to cancel the booking\033[1;37m\n");
                printf("\033[1;33m\t\t\t            Press Y/y to proceed to complete booking\n\033[1;37m\n");
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                      Name     \033[1;37m|  %s\n", current->guestName);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                      NID      \033[1;37m|  %s\n", current->nid);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                     E-mail    \033[1;37m|  %s\n", current->mail);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                     Phone     \033[1;37m|  +88 %s\n", current->phone);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                    Room No.   \033[1;37m|  %d \n", roomNum);
                printf("\t\t\t   ---------------------------------------------------------\n");
                printf("\t\t\t\033[1;36m                   Est. Bill   \033[1;37m|  %d \n", current->pay);
                printf("\t\t\t   ---------------------------------------------------------\n");
                char p;
                printf("\n\033[1;36m\t\t\t                      Confirm : \033[1;37m");
                scanf(" %c", &p);
                if (p == 'N' || p == 'n')
                {
                    cancelBooking(roomNum);
                    return;
                }
                else if (p == 'Y' || p == 'y')
                {
                    saveRoomDataToFile();
                    system("cls");
                    branding();
                    printf("\t\t\t   ---------------------------------------------------------\n");
                    printf("\t\t\t\033[1;33m                   Room No. %d has been booked!\033[1;37m\n", roomNum);
                    printf("\t\t\t\033[1;34m                       Returning to admin...\033[1;37m\n");
                    printf("\t\t\t   ---------------------------------------------------------\n");
                    Sleep(3000);
                    return;
                }
            }
            else
            {
                printf("\t\t\t\033[1;33m             There is no request for this room!\033[1;37m\n");
                Sleep(2000);
                return;
            }
        }
        current = current->next;
    }
    printf("\n\033[1;36m\t\t\t                   Room %d not found!\033[1;37m\n", roomNum);
    Sleep(2000);
}

void searchMail()
{
    char mail[MAX_MAIL_LENGTH];
    system("cls");
    branding();
    struct Room *current = head;
    printf("\033[1;36m\n\t\t\t\t\tEnter email      : \033[1;37m");
    scanf("%s", mail);
    int f = 0;

    while (current != NULL)
    {
        if (strcmp(current->mail, mail) == 0)
        {
            system("cls");
            branding();
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t\t|\033[1;34m                  -Guest info-                 \033[1;37m|\n");
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Name       \033[1;37m|  %s\n", current->guestName);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     NID        \033[1;37m|  %s\n", current->nid);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    E-mail      \033[1;37m|  %s\n", current->mail);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    Phone       \033[1;37m|  +88 %s\n", current->phone);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                   Room No.     \033[1;37m|  %01d \n", current->roomNumber);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-in Date   \033[1;37m|  %s \n", current->checkInDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-Out Date  \033[1;37m|  %s \n", current->checkOutDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Bill       \033[1;37m|  %d \n", current->pay);
            printf("\t\t\t   ---------------------------------------------------------\n");
            if (!current->isOccupied && current->req)
            {
                printf("\n\n\t\t\t  \033[1;33m                      Pending request!\033[1;37m");
            }
            f = 1;
        }

        current = current->next;
    }
    if (f == 0)
    {

        system("cls");
        branding();
        printf("\033[1;36m\n\t\t\t\t\t\tEmail Not found!!! \033[1;37m");
        Sleep(2000);
    }
    else if (f == 1)
    {
        printf("\n\n\t\t\t                  Press Enter to return to Database.");
        char chcc, ch6;
        scanf("%c%c", &chcc, &ch6);
        if (ch6 == '\n')
            return;
    }
}

void searchPhone()
{
    char phone[MAX_PHONE_LENGTH];
    system("cls");
    branding();
    struct Room *current = head;
    printf("\033[1;36m\n\t\t\t\t\tEnter phone number      : \033[1;37m");
    scanf("%s", phone);
    int f = 0;

    while (current != NULL)
    {
        if (strcmp(current->phone, phone) == 0)
        {
            system("cls");
            branding();
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t\t|\033[1;34m                  -Guest info-                 \033[1;37m|\n");
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Name       \033[1;37m|  %s\n", current->guestName);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     NID        \033[1;37m|  %s\n", current->nid);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    E-mail      \033[1;37m|  %s\n", current->mail);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    Phone       \033[1;37m|  +88 %s\n", current->phone);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                   Room No.     \033[1;37m|  %01d \n", current->roomNumber);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-in Date   \033[1;37m|  %s \n", current->checkInDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-Out Date  \033[1;37m|  %s \n", current->checkOutDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Bill       \033[1;37m|  %d \n", current->pay);
            printf("\t\t\t   ---------------------------------------------------------\n");
            if (!current->isOccupied && current->req)
            {
                printf("\n\n\t\t\t  \033[1;33m                      Pending request!\033[1;37m");
            }
            f = 1;
        }

        current = current->next;
    }
    if (f == 0)
    {

        system("cls");
        branding();
        printf("\033[1;36m\n\t\t\t\t\t    Phone Number Not found!!! \033[1;37m");
        Sleep(2000);
    }
    else if (f == 1)
    {
        printf("\n\n\t\t\t                  Press Enter to return to Database.");
        char chcc, ch6;
        scanf("%c%c", &chcc, &ch6);
        if (ch6 == '\n')
            return;
    }
}

void searchNID()
{
    char nid[MAX_NID_LENGTH];
    system("cls");
    branding();
    struct Room *current = head;
    printf("\033[1;36m\n\t\t\t\t\tEnter NID      : \033[1;37m");
    scanf("%s", nid);
    int f = 0;

    while (current != NULL)
    {
        if (strcmp(current->nid, nid) == 0)
        {
            system("cls");
            branding();
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t\t|\033[1;34m                  -Guest info-                 \033[1;37m|\n");
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Name       \033[1;37m|  %s\n", current->guestName);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     NID        \033[1;37m|  %s\n", current->nid);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    E-mail      \033[1;37m|  %s\n", current->mail);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    Phone       \033[1;37m|  +88 %s\n", current->phone);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                   Room No.     \033[1;37m|  %01d \n", current->roomNumber);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-in Date   \033[1;37m|  %s \n", current->checkInDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-Out Date  \033[1;37m|  %s \n", current->checkOutDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Bill       \033[1;37m|  %d \n", current->pay);
            printf("\t\t\t   ---------------------------------------------------------\n");
            if (!current->isOccupied && current->req)
            {
                printf("\n\n\t\t\t  \033[1;33m                      Pending request!\033[1;37m");
            }
            f = 1;
        }

        current = current->next;
    }
    if (f == 0)
    {

        system("cls");
        branding();
        printf("\033[1;36m\n\t\t\t\t\t\t NID Not found!!! \033[1;37m");
        Sleep(2000);
    }
    else if (f == 1)
    {
        printf("\n\n\t\t\t                  Press Enter to return to Database.");
        char chcc, ch6;
        scanf("%c%c", &chcc, &ch6);
        if (ch6 == '\n')
            return;
    }
}

void searchRoomnum()
{
    int roomNum;
    system("cls");
    branding();
    struct Room *current = head;
    printf("\033[1;36m\n\t\t\t\t\t         Enter Room No : \033[1;37m");
    scanf("%d", &roomNum);
    int f = 0;
    while (current != NULL)
    {
        if (current->roomNumber == roomNum)
        {
            system("cls");
            branding();
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t\t|\033[1;34m                  -Guest info-                 \033[1;37m|\n");
            printf("\t\t\t\t-------------------------------------------------\n");
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Name       \033[1;37m|  %s\n", current->guestName);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     NID        \033[1;37m|  %s\n", current->nid);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    E-mail      \033[1;37m|  %s\n", current->mail);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                    Phone       \033[1;37m|  +88 %s\n", current->phone);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                   Room No.     \033[1;37m|  %01d \n", current->roomNumber);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-in Date   \033[1;37m|  %s \n", current->checkInDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                Check-Out Date  \033[1;37m|  %s \n", current->checkOutDate);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m                     Bill       \033[1;37m|  %d \n", current->pay);
            printf("\t\t\t   ---------------------------------------------------------\n");
            if (!current->isOccupied && current->req)
            {
                printf("\n\n\t\t\t  \033[1;33m                      Pending request!\033[1;37m");
            }
            f = 1;
        }

        current = current->next;
    }
    if (f == 0)
    {
        system("cls");
        branding();
        printf("\033[1;36m\n\t\t\t\t\t\t Room Not found!!! \033[1;37m");
        Sleep(2000);
    }
    else if (f == 1)
    {
        printf("\n\n\t\t\t                  Press Enter to return to Database.");
        char chcc, ch6;
        scanf("%c%c", &chcc, &ch6);
        if (ch6 == '\n')
            return;
    }
}

void display_all_rooms()
{
    system("cls");
    branding();
    printf("\n");
    printf("\t\t\t\t\t    -------------------------\n");
    printf("\t\t\t\t\t    |\033[1;34m     \"Hotel Status\"    \033[1;37m|\n");
    printf("\t\t\t\t\t    -------------------------\n");
    printf("------------------------------------------------------------------------------------------------------------\n");
    struct Room *current = head;
    while (current != NULL)
    {
        if (current->isOccupied)
        {
            printf("\033[1;33m\nRoom No: %01d | Status: Booked | Checked-in: %s | Checked-out: %s | Fare: %d | Type: %s\033[1;37m\n", current->roomNumber, current->checkInDate, current->checkOutDate, current->cost, current->room_type);
            printf("------------------------------------------------------------------------------------------------------------\n");
        }
        else if (!current->isOccupied && current->req)
        {
            printf("\033[1;33m\nRoom No: %01d | Status: Pending | Fare: %d | Type: %s\033[1;37m\n", current->roomNumber, current->cost, current->room_type);
            printf("------------------------------------------------------------------------------------------------------------\n");
        }
        else if (!current->isOccupied && !current->req)
        {
            printf("\033[1;33m\nRoom No: %01d | Status: Free | Fare: %d | Type: %s\033[1;37m\n", current->roomNumber, current->cost, current->room_type);
            printf("------------------------------------------------------------------------------------------------------------\n");
        }
        current = current->next;
    }
    printf("\n\n\t\t\t                Press Enter to return to database.");
    char chc, ch2;
    scanf("%c%c", &chc, &ch2);
    if (ch2 == '\n')
        return;
}

void displayAvailableRooms(char *checkInDate, char *checkOutDate)
{
    printf("\n");
    printf("\t\t\t\t\t       \"Available Room(s)\"\n");
    printf("\t\t\t\t\t      ---------------------");
    printf("\n");
    struct Room *current = head;

    printf("\n\t\t    Available Rooms for Check-In Date: %s, Check-Out Date: %s\n\n", checkInDate, checkOutDate);
    while (current != NULL)
    {
        if ((!current->isOccupied && !current->req) ||
            (strcmp(current->checkOutDate, "N/A") == 0) ||      // Room has no check-out date
            (strcmp(current->checkInDate, "N/A") == 0) ||       // Room has no check-in date
            (strcmp(current->checkOutDate, checkInDate) < 0) || // Room's check-out date is before the check-in date
            (strcmp(current->checkInDate, checkOutDate) > 0))
        {
            // Room's check-in date is after the check-out date
            printf("\033[1;33m\t\t\t\t       Room No: %01d | Fare: %d | Type: %s\033[1;37m\n", current->roomNumber, current->cost, current->room_type);
        }
        else
        {
            int currentCheckOutDay, currentCheckOutMonth, currentCheckOutYear, inputCheckInDay, inputCheckInMonth, inputCheckInYear;
            sscanf(current->checkOutDate, "%d-%d-%d", &currentCheckOutDay, &currentCheckOutMonth, &currentCheckOutYear);
            sscanf(checkInDate, "%d-%d-%d", &inputCheckInDay, &inputCheckInMonth, &inputCheckInYear);

            if (currentCheckOutYear != inputCheckInYear || currentCheckOutMonth != inputCheckInMonth)
            {
                printf("\033[1;33m\t\t\t\t       Room No: %01d | Fare: %d | Type: %s\033[1;37m\n", current->roomNumber, current->cost, current->room_type);
            }
        }
        current = current->next;
    }
}

void cancelBooking(int roomNumber)
{
    struct Room *current = head;
    while (current != NULL)
    {
        if (current->roomNumber == roomNumber)
        {

            current->isOccupied = false;
            current->req = false;

            current->pay = 0;
            strcpy(current->guestName, "N/A");
            strcpy(current->mail, "N/A");
            strcpy(current->phone, "N/A");
            strcpy(current->nid, "N/A");
            strcpy(current->checkInDate, "N/A");
            strcpy(current->checkOutDate, "N/A");
            saveRoomDataToFile();
            return;
        }
        current = current->next;
    }
}

void checkoutRoom()
{
    system("cls");
    branding();
    printf("\n");
    printf("\t\t\t                          \" Check Out\"\n");
    printf("\t\t\t                         ----------------");
    printf("\n");
    struct Room *current = head;
    int roomNumber;
    printf("\t\t\t\t\t\033[1;36mEnter room number: \033[1;37m");
    scanf("%d", &roomNumber);

    while (current != NULL)
    {
        if (current->roomNumber == roomNumber)
        {
            system("cls");
            branding();
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m             Name     \033[1;37m|  %s\n", current->guestName);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m             NID      \033[1;37m|  %s\n", current->nid);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m            E-mail    \033[1;37m|  %s\n", current->mail);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m            Phone     \033[1;37m|  +88 %s\n", current->phone);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m           Room No.   \033[1;37m|  %01d \n", roomNumber);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t\033[1;36m             Bill     \033[1;37m|  %d \n", current->pay);
            printf("\t\t\t   ---------------------------------------------------------\n");
            printf("\t\t\t                          Confirm: ");
            char con;
            scanf(" %c", &con);
            if (con == 'y')
            {
                if (current->isOccupied)
                {

                    current->isOccupied = false;
                    current->req = false;

                    current->pay = 0;
                    strcpy(current->guestName, "N/A");
                    strcpy(current->mail, "N/A");
                    strcpy(current->phone, "N/A");
                    strcpy(current->nid, "N/A");
                    strcpy(current->checkInDate, "N/A");
                    strcpy(current->checkOutDate, "N/A");
                    saveRoomDataToFile();
                    system("cls");
                    branding();
                    printf("\t\t\t\033[1;36m                 Checkout completed of room no %d!\033[1;37m\n", roomNumber);
                    printf("\n\n\t\t\t                  Press Enter to return to admin.");
                    char chh, ch4;
                    scanf("%c%c", &chh, &ch4);
                    if (ch4 == '\n')
                        return;
                }
                else
                {
                    printf("\n\n\t\t\t                   Room %01d is already unoccupied!\n", roomNumber);
                    printf("\n\n\t\t\t                   Press Enter to return to admin.");
                    char chh, ch4;
                    scanf("%c%c", &chh, &ch4);
                    if (ch4 == '\n')
                        return;
                }
            }
            else
            {
                return;
            }
        }
        current = current->next;
    }
    printf("\t\t\t\t\t     Room %d not found.\n", roomNumber);
    Sleep(2000);
}

void pending()
{
    system("cls");
    system("cls");
    branding();
    printf("\n");
    printf("\t\t\t\t\t\033[1;34m    \"Pending Booking Requests\"\033[1;37m\n");
    printf("\t\t\t\t\t   ----------------------------");
    printf("\n");
    struct Room *current = head;
    int f = 0;
    while (current != NULL)
    {
        if (!current->isOccupied && current->req)
        {
            f = 1;
            printf("\033[1;33m\n\t\t\t     Room No: %01d | Status: Pending | Fare: %d | Type: %s\033[1;37m\n", current->roomNumber, current->cost, current->room_type);
        }
        current = current->next;
    }
    if (f == 0)
    {
        printf("\n\t\t\t\033[1;33m                        No Bookings Pending!\n\033[1;37m");
        printf("\n\n\t\t\t\033[1;36m                 Press Enter to return to homepage.\033[1;37m");
        char c, ch5;
        scanf("%c%c", &c, &ch5);
        if (ch5 == '\n')
            return;
    }
    printf("\n\n\t\t\t                Press 'N/n' to return to database.");
    if (f == 1)
        printf("\n\t\t\t                Press 'Y/y' to see booking options.");
    printf("\n\n\t\t\t\033[1;36m                        Proceed to book: \033[1;37m");
    char chc;
    scanf(" %c", &chc);
    if (chc == 'n')
        return;
    else if (chc == 'y')
        confirm();
}

void database()
{
back:
    system("cls");
    branding();
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t|\033[1;34m                  -Guest info-                 \033[1;37m|\n");
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t|                                               |\n");
    printf("\t\t\t\t|\033[1;36m             1. Search via Phone               \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m             2. Search via Email               \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m             3. Search via NID                 \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m             4. Search via Room No             \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m             5. See pending bookings           \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m             6. See hotel room status          \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m             0. Back                           \033[1;37m|\n");
    printf("\t\t\t\t|                                               |\n");
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t                                                 \n");
    printf("\t\t\t\t                    Submit: ");
    scanf("%d", &opt2);
    while (opt2)
    {
        if (opt2 == 1)
        {
            system("cls");
            searchPhone();
            goto back;
        }
        else if (opt2 == 2)
        {
            system("cls");
            searchMail();
            goto back;
        }
        else if (opt2 == 3)
        {
            system("cls");
            searchNID();
            goto back;
        }
        else if (opt2 == 4)
        {
            system("cls");
            searchRoomnum();
            goto back;
        }
        else if (opt2 == 5)
        {
            system("cls");
            pending();
            goto back;
        }
        else if (opt2 == 6)
        {
            system("cls");
            display_all_rooms();
            goto back;
        }
        else if (opt2 == 0)
        {
            break;
        }
        else
        {
            printf("\t\t\t\t             Wrong input. Submit again: ");
            scanf("%d", &opt2);
        }
    }
}

void admin()
{
    system("cls");
    branding();

    FILE *f;
    int flag = 0;
    f = fopen("database.txt", "r");
    char c[200], c1[100], c2[100], c3[100], c4[100], c5[100];
    printf("\n\t\t\t\t\t\033[1;37m---------------------------------\033[1;37m");
    printf("\n\t\t\t\t\t|\033[1;34m     -Administrator Login-     \033[1;37m|");
    printf("\n\t\t\t\t\t\033[1;37m---------------------------------\033[1;37m");
    printf("\n\t\t\t\t\t\033[1;36m  Enter ID      : \033[1;37m");
    scanf("%s", c3);
    printf("\n\t\t\t\t\t\033[1;36m  Enter password: \033[1;37m");
    scanf(" ");
    scanf("%s", c4);
    while (fgets(c, 205, f))
    {
        sscanf(c, "%s %s %[^\n]", c1, c2, c5);
        if (strcmp(c1, c3) == 0 && strcmp(c2, c4) == 0)
        {
            flag = 1;
            break;
        }
    }
    if (flag == 1)
    {
    back:
        system("cls");
        branding();
        printf("\n\t\t\t\tWelcome, %s!\n", c5);
        printf("\n");
        printf("\t\t\t\t-------------------------------------------------\n");
        printf("\t\t\t\t|\033[1;34m                    -Admin-                    \033[1;37m|\n");
        printf("\t\t\t\t-------------------------------------------------\n");
        printf("\t\t\t\t-------------------------------------------------\n");
        printf("\t\t\t\t|                                               |\n");
        printf("\t\t\t\t|\033[1;36m                 1. Check In                   \033[1;37m|\n");
        printf("\t\t\t\t|\033[1;36m                 2. Check Out                  \033[1;37m|\n");
        printf("\t\t\t\t|\033[1;36m                 3. Database                   \033[1;37m|\n");
        printf("\t\t\t\t|\033[1;36m                 0. Logout                     \033[1;37m|\n");
        printf("\t\t\t\t|                                               |\n");
        printf("\t\t\t\t-------------------------------------------------\n");
        printf("\t\t\t\t                                                 \n");
        printf("\t\t\t\t                    Submit: ");
        scanf("%d", &opt1);
        while (opt1)
        {
            if (opt1 == 1)
            {
                system("cls");
                checkIn();
                goto back;
            }
            else if (opt1 == 2)
            {
                system("cls");
                checkoutRoom();
                goto back;
            }
            else if (opt1 == 3)
            {
                system("cls");
                database();
                goto back;
            }
            else if (opt1 == 0)
            {
                break;
            }
            else
            {
                printf("\t\t\t\t             Wrong input. Submit again: ");
                scanf("%d", &opt1);
            }
        }
    }
    else
    {
        printf("\n\n\t\t\t\033[1;33m                     Invalid ID or Password!\033[1;37m\n\n");
        Sleep(2000);
        return;
    }
    system("cls");
    branding();
    printf("\n\n\t\t\t\033[1;33m                     Logged Out Successfully!\033[1;37m\n\n");
    Sleep(1000);
}

void homepage()
{
back:
    system("cls");
    branding();
    printf("\t\t\t\t\t\tWelcome to the app\n");
    printf("\t\t\t\t\t\t------------------\n");
    printf("\n");
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t|\033[1;34m                     -Home-                    \033[1;37m|\n");
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t|                                               |\n");
    printf("\t\t\t\t|\033[1;36m               1. Request a room               \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m               2. Login as an admin            \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m               3. About us                     \033[1;37m|\n");
    printf("\t\t\t\t|\033[1;36m               0. Exit                         \033[1;37m|\n");
    printf("\t\t\t\t|                                               |\n");
    printf("\t\t\t\t-------------------------------------------------\n");
    printf("\t\t\t\t                                                 \n");
    printf("\t\t\t\t                     Submit: ");
    scanf("%d", &opt);
    while (opt)
    {
        if (opt == 1)
        {
            system("cls");
            book_a_room();
            goto back;
        }
        else if (opt == 2)
        {
            system("cls");
            admin();
            goto back;
        }
        else if (opt == 3)
        {
            credit();
            goto back;
        }
        else if (opt == 0)
        {
            break;
        }
        else
        {
            printf("\t\t\t\t             Wrong input. Submit again: ");
            scanf("%d", &opt);
        }
    }
}

void freeRooms()
{
    struct Room *current = head;
    while (current != NULL)
    {
        struct Room *temp = current;
        current = current->next;
        free(temp);
    }
    head = NULL;
}

int main()
{
    loadRoomDataFromFile();
    welcome();
    homepage();
    byebye();
    freeRooms();
    return 0;
}
