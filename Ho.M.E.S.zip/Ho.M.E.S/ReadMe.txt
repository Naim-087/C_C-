To run the program-
- Open "Hotel management system" folder
- Open "output" folder
- Run "HotelManagementSystem.exe"

---There you go!---


* The room informations are saved to and shown from the "room_data.txt" file
* The admin ID and passwords are stored in "database.txt" file